# snake
Le jeu snake<br>
Ceci est un projet personnel que je réalise en suivant une formation dans le but d'apprende JavaScript.
